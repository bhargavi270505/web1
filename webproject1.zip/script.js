
  document.addEventListener
  ('DOMContentLoaded', function() {
    alert("Welcome to My Website!");
  });

